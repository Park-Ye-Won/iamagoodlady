from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time

# 드라이버 설정 및 옵션 추가
options = Options()
options.add_argument("--start-maximized")
options.add_argument("--disable-gpu")
options.add_argument("--no-sandbox")
# options.add_argument("--headless")  # GUI가 필요 없다면 헤드리스 모드로 실행
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

def search_novels_from_json(driver, file_path, n):
    extracted_titles_all = []  # 모든 제목을 저장할 리스트
    
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    titles = data.get('names', [])

    for title in titles:
        extracted_titles = []
        try:
            # 소설넷 홈 이동 및 검색 버튼 클릭
            driver.get('https://ssn.so/')
            WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, 'btn-search'))).click()

            # 검색어 입력 및 제출
            search_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'form-control'))
            )
            search_input.clear()
            search_input.send_keys(title)
            driver.execute_script("document.querySelector('.form-control').form.submit();")

            # 소설 썸네일 클릭
            search_pic = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, 'lazyloaded')))
            search_pic.click()

            # 특정 h4 요소로 스크롤
            h4_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//h4[text()='이 작가의 다른 웹소설']"))
            )
            driver.execute_script("arguments[0].scrollIntoView(true);", h4_element)
            time.sleep(1)

            # 이 작가의 다른 웹소설 가져오기
            products = WebDriverWait(driver, 10).until(
                EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".product.card.card-custom"))
            )

            # 이 작가의 다른 웹소설 n개 추출
            for product in products[:n]:
                try:
                    # 카테고리, 작가, 제목 추출
                    category = product.find_element(By.CLASS_NAME, "product-category").text
                    author = product.find_element(By.CLASS_NAME, "product-author").text
                    novel_title = product.find_element(By.CLASS_NAME, "product-title").text

                    # 평점 요소가 존재하는지 확인 후 추출
                    try:
                        reviews = product.find_element(By.CLASS_NAME, "product-reviews").text
                    except:
                        reviews = "평점 정보 없음"  # 평점 요소가 없을 경우 기본 값 설정

                    # 'product-introduction three-line' 요소가 존재하는지 확인 후 추출
                    try:
                        introduction = product.find_element(By.CSS_SELECTOR, ".product-introduction.three-line").text
                    except:
                        introduction = "소개 정보 없음"  # 소개 정보가 없을 경우 기본 값 설정

                    # 추출된 소설 정보를 리스트에 저장
                    extracted_titles.append({
                        "카테고리": category,
                        "작가": author,
                        "제목": novel_title,
                        "평점": reviews,
                        "소개": introduction
                    })

                except Exception as e:
                    print(f"정보를 추출하는 데 오류가 발생했습니다: {e}")

            # 제목과 추천 소설 목록 추가
            extracted_titles_all.append({"title": title, "recommendations": extracted_titles})
        except Exception as e:
            print(f"'{title}'에 대한 추천 작품 정보를 찾는 데 오류가 발생했습니다: {e}")

    # 결과를 JSON 파일로 저장
    with open('novels_recommendations.json', 'w', encoding='utf-8') as json_file:
        json.dump(extracted_titles_all, json_file, ensure_ascii=False, indent=4)

    return extracted_titles_all  # 결과 반환

# 사용 예시
try:
    results = search_novels_from_json(driver, 'top_300_without_19.json', 5)
    for title, recommendations in results:
        if recommendations:
            print(f"'{title}'에 대한 추천 소설 목록:")
            for rec in recommendations:
                print(rec)
        else:
            print(f"'{title}'에 대한 추천 소설 목록: 추천 소설을 찾지 못했습니다.")
except Exception as e:
    print("전체 과정에서 오류 발생:", e)
finally:
    driver.quit()
