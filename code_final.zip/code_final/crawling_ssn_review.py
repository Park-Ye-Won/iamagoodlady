# 자동 크롤링
from selenium import webdriver # 드라이버 
from selenium.webdriver.chrome.service import Service # Chrom 서비스
from webdriver_manager.chrome import ChromeDriverManager # 크롬드라이버 관리자 
from selenium.webdriver.common.keys import Keys # 엔터키 역할
from selenium.webdriver.common.by import By # 로케이터
import os # 실행파일 경로
import json # json 파일 불러오기

# driver 생성 
driver_path = ChromeDriverManager().install() # 드라이버 설치 경로 
correct_driver_path = os.path.join(os.path.dirname(driver_path), "chromedriver.exe") # 실행파일경로 
driver = webdriver.Chrome(service=Service(executable_path=correct_driver_path)) # 드라이버 생성

# 1. Json 파일 불러오기
path = r"C:\ITWILL\3_SemiProject\data crawling"

with open(path + "/names.json", mode='r', encoding='utf-8') as file:
    data = json.load(file)
    titles = data["names"]

len(titles) # 292

# 원소 확인 
# print(titles[227]) # 어두운 바다의 등불이 되어 [연재]
# print(titles[234]) # 갓 오브 블랙필드 [단행본]

# 크롤링 돌리기
for title in titles[235:293] : # 현재 0~227/228~234/235~293 크롤링
    
    # 2. 대상 url 이동 : 소설넷 홈   
    driver.get('https://ssn.so/')
    url = driver.current_url
    print('접속한 url =', url)
    driver.implicitly_wait(2) # 2초 대기(자원 loading)

    # 3. 소설넷 > 검색 창
    element = driver.find_element(By.XPATH, '//*[@id="btn-search"]') # a 태그
    element.click() # 링크 클릭
    driver.implicitly_wait(2) # 2초 대기(자원 loading)

    # 4. 입력상자 가져오기
    elem = driver.find_element(By.NAME, 'keyword')

    # 5. 검색어 입력 -> 엔터 
    elem.send_keys(title) # 검색어 입력 
    elem.send_keys(Keys.ENTER) # 엔터 키
    driver.implicitly_wait(2) # 2초 대기(자원 loading)

    # 6. 첫번째 검색 결과로 이동
    element = driver.find_element(By.XPATH, '/html/body/div[1]/section[2]/div/div/div/div/div[2]/div[3]/h3/a') # a 태그
    element.click() # 링크 클릭
    driver.implicitly_wait(2) # 2초 대기(자원 loading)

    # 7. 해당 웹소설 리뷰(~50개) 수집
    reviews = []

    for i in range(3, 6):
        try : 
            for j in range(1, 31):  # 최대 30개의 리뷰 시도
                try:
                    review = driver.find_element(By.XPATH, f"/html/body/div[1]/section/div/div/div/div[2]/div[5]/div/div[{j}]/div[2]/div[2]/div") 
                    reviews.append(review.text)
                    if len(reviews) >= 50:  # 50개의 리뷰를 모으면 종료
                        break
                except Exception:
                    print('이 페이지에 더 이상 리뷰가 없거나 리뷰 요소를 찾을 수 없습니다.')
                    break  # 리뷰가 없으면 내부 루프 종료
                    
            link = driver.find_element(By.XPATH, f"/html/body/div[1]/section/div/div/div/div[2]/div[5]/div/ul/li[{i}]/a")
            link.click()  # 링크 클릭                
            driver.implicitly_wait(2)  # 로딩 대기            
        except :
            print('종료')
            break

    # 8. 수집한 리뷰 json 파일 저장
    if reviews:
        # print(f"수집된 리뷰: {reviews}, 총 리뷰 개수: {len(reviews)}")
        print("리뷰 수집을 완료했습니다")
        
        # 기존 데이터 로드
        if os.path.exists('reviews.json'):
            with open('reviews.json', 'r', encoding='utf-8') as json_file:
                existing_data = json.load(json_file)
        else:
            existing_data = {}

        # 새로운 리뷰 데이터 추가
        if title in existing_data:
            existing_data[title].extend(reviews)
        else:
            existing_data[title] = reviews

        # 업데이트된 데이터를 JSON 파일로 저장
        with open('reviews.json', 'w', encoding='utf-8') as json_file:
            json.dump(existing_data, json_file, ensure_ascii=False, indent=4)
    else:
        print("리뷰가 수집되지 않았습니다.")

# 크롤링 종료
driver.close() # 창 닫기 
print('크롤링 종료')


# 수동적 크롤링
 
from selenium import webdriver # 드라이버 
from selenium.webdriver.chrome.service import Service # Chrom 서비스
from webdriver_manager.chrome import ChromeDriverManager # 크롬드라이버 관리자 
from selenium.webdriver.common.keys import Keys # 엔터키 역할
from selenium.webdriver.common.by import By # 로케이터
import os # 실행파일 경로
import json # json 파일 불러오기

# 1. 제목(title) 입력
title = input('제목 : ')

# driver 생성 
driver_path = ChromeDriverManager().install() # 드라이버 설치 경로 
correct_driver_path = os.path.join(os.path.dirname(driver_path), "chromedriver.exe") # 실행파일경로 
driver = webdriver.Chrome(service=Service(executable_path=correct_driver_path)) # 드라이버 생성

# 2. 대상 url 이동 : 소설넷 홈   
driver.get('https://ssn.so/')
url = driver.current_url
print('접속한 url =', url)
driver.implicitly_wait(2) # 2초 대기(자원 loading)

# 3. 소설넷 > 검색 창
element = driver.find_element(By.XPATH, '//*[@id="btn-search"]') # a 태그
element.click() # 링크 클릭
driver.implicitly_wait(2) # 2초 대기(자원 loading)

# 4. 입력상자 가져오기
elem = driver.find_element(By.NAME, 'keyword')

# 5. 검색어 입력 -> 엔터 
elem.send_keys(title) # 검색어 입력 
elem.send_keys(Keys.ENTER) # 엔터 키
driver.implicitly_wait(2) # 2초 대기(자원 loading)

# 6. 첫번째 검색 결과로 이동
element = driver.find_element(By.XPATH, '/html/body/div[1]/section[2]/div/div/div/div/div[2]/div[3]/h3/a') # a 태그
element.click() # 링크 클릭
driver.implicitly_wait(2) # 2초 대기(자원 loading)

# 7. 해당 웹소설 리뷰(~약 50개) 수집
reviews = []

for i in range(3, 6):
    try : 
        for j in range(1, 31):  # 최대 30개의 리뷰 시도
            try:
                review = driver.find_element(By.XPATH, f"/html/body/div[1]/section/div/div/div/div[2]/div[5]/div/div[{j}]/div[2]/div[2]/div") 
                reviews.append(review.text)
                if len(reviews) >= 50:  # 50개의 리뷰를 모으면 종료
                    break
            except Exception:
                print('이 페이지에 더 이상 리뷰가 없거나 리뷰 요소를 찾을 수 없습니다.')
                break  # 리뷰가 없으면 내부 루프 종료                
        link = driver.find_element(By.XPATH, f"/html/body/div[1]/section/div/div/div/div[2]/div[5]/div/ul/li[{i}]/a")
        link.click()  # 링크 클릭           
        driver.implicitly_wait(2)  # 로딩 대기       
    except :
        print('종료')
        break

# 8. 수집한 리뷰 json 파일 저장
if reviews:
    # print(f"수집된 리뷰: {reviews}, 총 리뷰 개수: {len(reviews)}")
    print("리뷰 수집을 완료했습니다")
    
    # 기존 데이터 로드
    if os.path.exists('reviews.json'):
        with open('reviews.json', 'r', encoding='utf-8') as json_file:
            existing_data = json.load(json_file)
    else:
        existing_data = {}

    # 새로운 리뷰 데이터 추가
    if title in existing_data:
        existing_data[title].extend(reviews)
    else:
        existing_data[title] = reviews

    # 업데이트된 데이터를 JSON 파일로 저장
    with open('reviews.json', 'w', encoding='utf-8') as json_file:
        json.dump(existing_data, json_file, ensure_ascii=False, indent=4)
else:
    print("리뷰가 수집되지 않았습니다.")

# 크롤링 종료
driver.close() # 창 닫기 
print('크롤링 종료')



# json 파일 key명 변경 : 어두운 바다의 등불이 되어, 갓 오브 블랙필드

# 1. JSON 파일 읽기
path = r"C:\ITWILL\3_SemiProject\data crawling"

with open(path + "/reviews.json", mode='r', encoding='utf-8') as file:
    data = json.load(file)

# 2. 키 이름 변경
if '갓 오브 블랙필드' in data:
    data['갓 오브 블랙필드 [단행본]'] = data.pop('갓 오브 블랙필드')

# 3. 변경된 JSON 파일 저장하기
with open('reviews.json', 'w', encoding='utf-8') as json_file:
    json.dump(data, json_file, ensure_ascii=False, indent=4)