from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import json
import os
import time

# 1. driver 생성 
# 1. 크롬 driver 생성 
driver_path = ChromeDriverManager().install() # 드라이버 설치 경로 
correct_driver_path = os.path.join(os.path.dirname(driver_path), "chromedriver.exe") # 실행파일경로 
driver = webdriver.Chrome(service=Service(executable_path=correct_driver_path)) # 드라이버 생성 
driver.maximize_window()

# json 파일에서 url 읽어오기
with open('urls.json', 'r', encoding="utf-8") as url_json:
    data = json.load(url_json)
    urls = data.get('urls', [])

# 결과 저장을 위한 dictionary
details = {}

for url in urls:
    # 2. 대상 url 이동 : 카카오페이지 웹소설 상세 페이지
    driver.get(url + '?tab_type=about')
    print('접속한 url =', driver.current_url)
    time.sleep(5)  # js 로딩 될 때까지 멈춤
    
    data_result = {}
    
    # 3. 정보 수집
    author = driver.find_element(By.XPATH, '/html/body/div/div/div[2]/div[1]/div[1]/div[1]/div/div[2]/a/div/span[2]')
    author_text = author.text.replace('\n', ' ').strip()
    plot = driver.find_element(By.XPATH, '/html/body/div/div/div[2]/div[1]/div[2]/div[2]/div/div/div[1]/div/div[2]/div/div/span')
    plot_text = plot.text.replace('\n', ' ').strip()
    try: 
        keyword = driver.find_element(By.XPATH, '/html/body/div/div/div[2]/div[1]/div[2]/div[2]/div/div/div[2]/div[2]/div')
        keyword_text = keyword.text.replace('\n', ' ').strip()
    except:
        keyword_text = ''
    
    # 데이터 저장
    data_result['author'] = author_text
    data_result['plot'] = plot_text
    
    if '이 작가의' not in keyword_text or keyword_text != '' : 
        data_result['keyword'] = keyword_text
    else : 
        data_result['keyword'] = ''
    
    # url별 데이터를 details 딕셔너리에 추가
    details[url] = data_result

# JSON 파일로 저장
with open('details.json', "w", encoding="utf-8") as file:
    json.dump(details, file, ensure_ascii=False, indent=4)

driver.quit()  # 드라이버 종료