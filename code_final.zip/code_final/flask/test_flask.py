import csv
from flask import Flask, render_template, request
from service.test_recommend import novel_search

app = Flask(__name__, static_folder='static')

@app.route('/')
def index():
    return render_template('test_main.html')

@app.route('/service1', methods=['GET'])
def service1():
    novel_content = request.args.get('novel_content')
    sim_result, novel_title = novel_search(novel_content)  # 유사도 분석 결과 호출

    # CSV 파일에서 소설 정보를 가져오기
    books = {}
    with open('info_final.csv', mode='r', encoding='utf-8') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            books[row['name']] = row  # 소설 제목을 키로 사용하여 딕셔너리에 저장

    # 추천 소설 목록에서 책 정보 가져오기
    recommended_books = [books.get(title) for title in novel_title if title in books]

    return render_template('test_index.html', sim_result=sim_result, novel_title=novel_title, recommended_books=recommended_books)

@app.route('/service2', methods=['GET'])
def service2():
    author = request.args.get('author')  # 작가명을 쿼리 파라미터로 받음
    
    with open('recommendation.csv', mode='r', encoding='utf-8') as file:
        csv_reader = csv.DictReader(file)
        others = [row for row in csv_reader]  # 각 행을 딕셔너리로 변환하여 리스트에 저장

    # 선택한 작가의 모든 작품 정보 필터링
    selected_books = [other for other in others if other['author'] == author]
    
    seen = set() # 중복값 제거
    filtered_books = []
    for book in selected_books:
        key = (book['author'], book['title'])  # (작가, 제목) 튜플을 키로 사용
        if key not in seen:
            seen.add(key)
            filtered_books.append(book)

    return render_template('test_rec.html', others=filtered_books)  # 변수 이름을 'others'로 변경


if __name__ == '__main__':
    app.run(port=80)