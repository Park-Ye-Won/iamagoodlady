import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import string

# 데이터셋 로드
path = r'C:\Users\Kyuri\Desktop\mid_project\flask'
data = pd.read_csv(path + r'\info_final.csv')
texts = data['cont']

def text_prepro(texts):
    texts = [''.join(ch for ch in st if ch not in string.punctuation) for st in texts]
    texts = [''.join(ch for ch in st if ch not in string.digits) for st in texts]
    texts = [' '.join(x.split()) for x in texts]
    return texts

# 전처리 실행
texts = text_prepro(texts)
max_features = 70000
obj = TfidfVectorizer(max_features=max_features, ngram_range=(1, 2))
novel_dtm = obj.fit_transform(texts)
novel_dtm_arr = novel_dtm.toarray()
name = data['name'].tolist()  # 제목 리스트로 변환

def novel_search(query):
    query_data = text_prepro([query])
    query_dtm = obj.transform(query_data)
    query_dtm_arr = query_dtm.toarray()
    sim = cosine_similarity(query_dtm_arr, novel_dtm_arr).reshape(-1)
    sim_idx = sim.argsort()[::-1]

    sim_result = []
    novel_title = []
    
    for idx in sim_idx[:4]:
        sim_result.append(sim[idx])
        novel_title.append(name[idx])
        
    return sim_result, novel_title

# novel_search(input('search query input : '))